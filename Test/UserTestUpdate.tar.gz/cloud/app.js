// 在Cloud code里初始化express框架
var express = require('express');
var app = express();
var avosExpressHttpsRedirect = require('avos-express-https-redirect');
var avosExpressCookieSession = require('avos-express-cookie-session');

// App全局配置
//设置模板目录
app.set('views', 'cloud/views');
app.set('view engine', 'ejs');    // 设置template引擎
app.use(avosExpressHttpsRedirect()); //启用HTTPS
app.use(express.bodyParser());    // 读取请求body的中间件
app.use(express.cookieParser('FrENkCieRk'));// cookie secure
app.use(avosExpressCookieSession({ cookie: { maxAge: 3600000 }, fetchUser: true, key: 'Test'}));
app.use(express.cookieSession({ key:'Test.sess'}));

//使用express路由API服务/hello的http GET请求

//var Board = AV.Object.extend('Board');


app.get('/',function(req,res){
	res.render('index');
});

app.get('/signin', function(req, res){
	var username;
	if(AV.User.current()) {
		username = AV.User.current().getUsername();
	}
	res.render('signin', {username: username});
});

app.post('/signin', function(req, res) {
	AV.User.logIn(req.body.username, req.body.password).then(function() {
		var currentUser = AV.User.current();
		var username = currentUser.getUsername();
		req.session.username = username;
		res.redirect('back');
		//res.send("success");
	},function(error) {
		res.send("fail");
	})
});

app.get('/signup', function(req, res) {
	res.render('signup');

});

app.post('/signup', function(req, res) {
	var user = new AV.User();
	console.log(req.body.username);
	console.log(req.body.password);
	user.set("username", req.body.username);
	user.set("password", req.body.password);
	user.signUp(null, {
		success: function(user) {
			//console.log('success');
			//console.log(user);
			res.redirect('/');
		},
		error: function(user, error) {
			//console.log('fail');
			console.log(user);
			console.log(error);
			res.send(error.message);
		}
	});
});

app.get('/signout', function(req, res) {
	AV.User.logOut();
	req.session.username = null;
	console.log(req.session.username);
	res.redirect('back');
});

// This line is required to make Express respond to http requests.
app.listen();
